package com.restws;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("/hello")
public class Message {
	 // This method is called if TEXT_PLAIN is request
	  @GET
	  @Produces(MediaType.TEXT_PLAIN)
	public String sayPlainTextHello() {
	    return "Have a nice day!!";
	  }
	// This method is called if XML is request
	  @GET
	  @Produces(MediaType.TEXT_XML)
	public String sayXMLHello() {
	    return "<?xml version=\"1.0\"?>" + "<hello> Have a nice day!" + "</hello>";
	  }
	// This method is called if HTML is request
	  @GET
	  @Produces(MediaType.TEXT_HTML)
	 public String sayHtmlHello() {
		    return "<html> " + "<title>" + "Have a nice day" + "</title>"
		        + "<body><h1>" + "Have a nice day" + "</body></h1>" + "</html> ";
		  }
}
