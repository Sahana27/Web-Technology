package com;

import java.io.File;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class Client {
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("hello.xml");
		IHelloWorld helloWorld = (IHelloWorld) context.getBean("helloWorld");
		System.out.println(helloWorld);
		System.out.println(context.getBean("helloWorld"));
		System.out.println(helloWorld.hello());
	}

}
