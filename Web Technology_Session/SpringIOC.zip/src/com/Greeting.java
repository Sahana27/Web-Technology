package com;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.InitializingBean;

public class Greeting implements InitializingBean {
	@PostConstruct
	public void load() {
		System.out.println("Post construct");
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public void init() {
		System.out.println("Greeting init()");
	}
	public void clean() {
		System.out.println("Greeting clean()");
	}
	private String message;
	
	public Greeting() {
		// TODO Auto-generated constructor stub
	}
	public String sayHello() {
		return message;
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Initializing bean");
	}
}
