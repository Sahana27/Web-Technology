package com;

import org.springframework.beans.factory.BeanNameAware;

public class HelloWorld implements IHelloWorld { //, BeanNameAware {
	private String message;
	//private Greeting greeting;

	/*public void setGreeting(Greeting greeting) {
		this.greeting = greeting;
	}*/

	public HelloWorld() {
		System.out.println("Object constructed!");
	}
	
	public HelloWorld(String message) {
		super();
		this.message = message;
	}

	public String hello() {
		//return greeting.sayHello()+" "+message;
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
/*
	@Override
	public void setBeanName(String arg0) {
		System.out.println(arg0);
	}
	*/
}
