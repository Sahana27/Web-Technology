package com;

public interface IHelloWorld {
	public String hello();
}
