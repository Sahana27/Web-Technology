package com.simple1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

    public static void main(String[] args) {
//        ApplicationContext context = new ClassPathXmlApplicationContext();
        
        ApplicationContext context = 
        		new ClassPathXmlApplicationContext("beans1.xml");
        SequenceGenerator generator = 
        		(SequenceGenerator) context.getBean("sequenceGenerator");
        System.out.println("Generetor details ");
        System.out.println("Prefix:"+generator.getSequence());
        
        SequenceGenerator generator1 = 
        		(SequenceGenerator) context.getBean("sequenceGenerator");
        System.out.println("Generetor details ");
        System.out.println("Prefix:"+generator1.getSequence());
        
        

    }
}
