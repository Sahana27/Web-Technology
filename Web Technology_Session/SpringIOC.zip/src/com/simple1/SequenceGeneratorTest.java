package com.simple1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SequenceGeneratorTest {
	ApplicationContext context;
	SequenceGenerator generator;
	public SequenceGeneratorTest() {
		context = new ClassPathXmlApplicationContext("beans1.xml");

	}

	@Before
	public void setUp() throws Exception {
		generator = (SequenceGenerator) context
				.getBean("sequenceGenerator");
		
	}

	@After
	public void tearDown() throws Exception {
		generator = null;
	}

	@Test
	public void test1() {
		System.out.println("Generetor details ");
		System.out.println("Prefix:" + generator.getSequence());
	}
	@Test
	public void test2() {
		System.out.println("Generetor details ");
		System.out.println("Prefix:" + generator.getSequence());
	}

}
