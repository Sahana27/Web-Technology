package com.simple2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {

    public static void main(String[] args) {
        ApplicationContext context = 
            new ClassPathXmlApplicationContext("beans2.xml");

        SequenceGenerator generator =
            (SequenceGenerator) context.getBean("sequenceGenerator1");
        System.out.println("Generetor details ");
        System.out.println("Prefix:"+generator.getSequence());
        

    }
}
