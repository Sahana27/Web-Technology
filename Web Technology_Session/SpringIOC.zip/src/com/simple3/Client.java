package com.simple3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Client {

    public static void main(String[] args) {
        ApplicationContext context = 
            new ClassPathXmlApplicationContext("beans4.xml");

        SequenceGenerator generator =
            (SequenceGenerator) context.getBean("sequenceGenerator");
        System.out.println("Generetor details ");
        System.out.println("Prefix:"+generator.getSequence());
        

    }
}
