package com.simple3;

public interface PrefixGenerator {

    public String getPrefix();
}
