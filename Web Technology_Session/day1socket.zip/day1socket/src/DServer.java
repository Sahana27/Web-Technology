// Set up a Server that will receive packets from a
// client and send packets to a client.
import java.io.*;
import java.net.*;
import java.awt.*;


public class DServer extends Frame {
   private TextArea display;

   private DatagramPacket sendPacket, receivePacket;
   private DatagramSocket socket;

   public DServer()
   {
      super( "Server" );
      display = new TextArea();
      add( display, BorderLayout.CENTER );
      setSize( 400, 300 );
      setVisible( true );

      try {
         socket = new DatagramSocket( 5000 );
      }
      catch( SocketException se ) {
         se.printStackTrace();
         System.exit( 1 );
      }
   }

   public void waitForPackets()
   {
      while ( true ) {
         try {
            // set up packet
            byte data[] = new byte[ 100 ];
            receivePacket =
               new DatagramPacket( data, data.length );

            // wait for packet
            socket.receive( receivePacket );
 
            // process packet
            display.append( "\nPacket received:" +
               "\nFrom host: " + receivePacket.getAddress() +
               "\nHost port: " + receivePacket.getPort() +
               "\nLength: " + receivePacket.getLength() +
               "\nContaining:\n\t" + 
               new String( receivePacket.getData() ) );

            // echo information from packet back to client
            display.append( "\n\nEcho data to client...");
            sendPacket = new DatagramPacket(
                                receivePacket.getData(),
                                receivePacket.getLength(),
                                receivePacket.getAddress(),
                                receivePacket.getPort() );
            socket.send( sendPacket );
            display.append( "Packet sent\n" );
         }
         catch( IOException io ) {
            display.append( io.toString() + "\n" );
            io.printStackTrace();
         }
      }
   }

   public static void main( String args[] )
   {
      DServer s = new DServer();

      s.addWindowListener( new CloseWindowAndExit() );
      s.waitForPackets();
   }
}
