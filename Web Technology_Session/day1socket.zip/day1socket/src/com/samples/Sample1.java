package com.samples;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Sample1 {

	public static void main(String[] args) throws UnknownHostException {
		System.out.println(InetAddress.getLocalHost());
	}

}
