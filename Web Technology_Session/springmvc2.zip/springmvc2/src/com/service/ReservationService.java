package com.service;

import java.util.List;

import com.domain.Reservation;
import com.domain.SportType;

public interface ReservationService {

    public void make(Reservation reservation)
            throws ReservationNotAvailableException;

    public List<SportType> getAllSportTypes();

    public SportType getSportType(int sportTypeId);
}
