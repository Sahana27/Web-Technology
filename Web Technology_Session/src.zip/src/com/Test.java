package com;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static void main(String[] args) {
        ApplicationContext context =
            new ClassPathXmlApplicationContext("beans-hibernate.xml");
        Scanner read = new Scanner(System.in);
        CourseDao courseDao = (CourseDao) context.getBean("courseDao");

        Course course = new Course();
        System.out.println("Enter course name:");
        course.setTitle(read.next());
        course.setBeginDate(new GregorianCalendar(2007, 8, 1).getTime());
        course.setEndDate(new GregorianCalendar(2007, 9, 1).getTime());
        System.out.println("Enter the course fee:");
        course.setFee(read.nextInt());
        courseDao.store(course);

        List<Course> courses = courseDao.findAll();
        System.out.println("Current courses are :");
        for(int i=0;i<courses.size();i++) {
        	Course c = (Course)courses.get(i);
        	System.out.println(c.getId()+" : "+c.getTitle());
        }
        System.out.println("Enter the couse id");
        course = courseDao.findById(read.nextLong());
        if(null!=course) {
        System.out.println("Course Title: " + course.getTitle());
        System.out.println("Begin Date: " + course.getBeginDate());
        System.out.println("End Date: " + course.getEndDate());
        System.out.println("Fee: " + course.getFee());
        } else {
        	System.out.println("Not a valid course id");
        }
        //courseDao.delete(courseId);
    }
}
