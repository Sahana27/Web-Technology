package com.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Course;
import com.CourseDao;

public class HibernateTemplateCourseDao implements CourseDao {

	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	@Transactional
	public void store(Course course) {
		hibernateTemplate.saveOrUpdate(course);
	}
	@Transactional
	public void delete(Long courseId) {
		Course course = (Course) hibernateTemplate.get(Course.class, courseId);
		hibernateTemplate.delete(course);
	}
	@Transactional(readOnly = true)
	public Course findById(Long courseId) {
		return (Course) hibernateTemplate.get(Course.class, courseId);
	}
	@Transactional(readOnly = true)
	public List<Course> findAll() {
		return hibernateTemplate.find("from Course");
	}
}
