
import com.ts.*;
import javax.xml.ws.Endpoint;

public class TimeServiceProducer {

 public static void main(String [] args) {
	System.out.println("TimeService started....");
	Endpoint.publish("http://localhost:5500/ts",new TimeServiceImpl());
 }
}