package client;

import java.net.MalformedURLException;
import java.net.URL;

public class TimeServiceClient {
	public static void main(String[] args) throws MalformedURLException {
		TimeServiceImplService ts = new TimeServiceImplService(new URL("http://localhost:5500/ts?wsdl"));
		TimeService timeService = ts.getTimeServiceImplPort();
		System.out.println(timeService.getTimeAsString());
		System.out.println(timeService.getTimeAsElapsed());
	}
}
