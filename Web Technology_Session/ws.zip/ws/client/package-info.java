@javax.xml.bind.annotation.XmlSchema(namespace = "http://ts.com/")
package client;
