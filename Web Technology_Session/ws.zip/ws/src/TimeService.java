package com.ts;

import javax.jws.WebService;
import javax.jws.WebMethod;


@WebService
public interface TimeService {
	@WebMethod
	public String getTimeAsString();
	@WebMethod
	public long getTimeAsElapsed();
}